-- MR / SHADY SAAD cloud database setup for Supabase
-- Paste the whole script into Supabase > SQL Editor > New query > Run.
create extension if not exists pgcrypto;

create table if not exists public.students (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name text not null,
  grade text default '',
  group_name text default '',
  phone text default '',
  monthly_fee numeric(10,2) not null default 0,
  start_date date,
  notes text default '',
  created_at timestamptz not null default now()
);

create table if not exists public.attendance (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  date date not null default current_date,
  time time not null default localtime,
  status text not null default 'حاضر' check (status in ('حاضر','غائب','متأخر')),
  created_at timestamptz not null default now(),
  unique(student_id, date)
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  amount numeric(10,2) not null check (amount > 0),
  payment_date date not null default current_date,
  month_key text not null,
  method text default 'نقدي',
  notes text default '',
  created_at timestamptz not null default now()
);

alter table public.students enable row level security;
alter table public.attendance enable row level security;
alter table public.payments enable row level security;

drop policy if exists "owner students all" on public.students;
create policy "owner students all" on public.students
for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "owner attendance all" on public.attendance;
create policy "owner attendance all" on public.attendance
for all to authenticated using (
  auth.uid() = user_id and exists (
    select 1 from public.students s where s.id = attendance.student_id and s.user_id = auth.uid()
  )
) with check (
  auth.uid() = user_id and exists (
    select 1 from public.students s where s.id = attendance.student_id and s.user_id = auth.uid()
  )
);

drop policy if exists "owner payments all" on public.payments;
create policy "owner payments all" on public.payments
for all to authenticated using (
  auth.uid() = user_id and exists (
    select 1 from public.students s where s.id = payments.student_id and s.user_id = auth.uid()
  )
) with check (
  auth.uid() = user_id and exists (
    select 1 from public.students s where s.id = payments.student_id and s.user_id = auth.uid()
  )
);

create index if not exists students_user_id_idx on public.students(user_id);
create index if not exists attendance_user_date_idx on public.attendance(user_id, date);
create index if not exists payments_user_month_idx on public.payments(user_id, month_key);

-- Optional: enable Realtime so changes appear on the other device quickly.
do $$
begin
  alter publication supabase_realtime add table public.students;
exception when duplicate_object then null;
when undefined_object then null;
end $$;
do $$
begin
  alter publication supabase_realtime add table public.attendance;
exception when duplicate_object then null;
when undefined_object then null;
end $$;
do $$
begin
  alter publication supabase_realtime add table public.payments;
exception when duplicate_object then null;
when undefined_object then null;
end $$;
